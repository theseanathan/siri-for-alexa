# siri-for-alexa
Amazon Global Hackathon - Best Use of Alexa in the Kitchen
