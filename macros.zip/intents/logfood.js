function logfood() {
    
}
